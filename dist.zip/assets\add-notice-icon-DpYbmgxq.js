const s="/assets/result-icon-sIxJtkSb.png",t="/assets/add-notice-icon-D9PMfyll.png";export{t as a,s as r};
